# Growing value interpolation
This interpolation method aims to maintain data conservatism across a set of data.